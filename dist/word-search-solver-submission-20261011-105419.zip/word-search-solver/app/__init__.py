"""Word Search Solver API."""
