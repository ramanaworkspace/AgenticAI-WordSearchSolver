"""Request and response schemas."""
